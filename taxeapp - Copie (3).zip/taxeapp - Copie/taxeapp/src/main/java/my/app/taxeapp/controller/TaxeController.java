package my.app.taxeapp.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import my.app.taxeapp.bean.TaxForm;
import my.app.taxeapp.service.TaxeCalculationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
@Controller
@RequestMapping("/api/tax")
public class TaxeController {

    @Autowired
    private TaxeCalculationService taxCalculationService;

    @PostMapping("/calculateTax")
    public String calculateTax(
            @RequestParam(name = "cin") String cin,
            @RequestParam(name = "year") Integer year,
            @RequestParam(name = "terrainType") String terrainType,
            Model model) {
        double calculatedTax = taxCalculationService.calculateTax(year, cin, terrainType);
        model.addAttribute("calculatedTax", calculatedTax);
        return "taxResult";
    }

}

